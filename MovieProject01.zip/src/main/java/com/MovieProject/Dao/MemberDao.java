package com.MovieProject.Dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.MovieProject.Dto.Member;

public interface MemberDao {

	Member selectMemberInfo(String id);

	int insertMember_kakao(Member member);

	int insertMember(Member member);

	Member selectLoginMember(@Param("mid") String userId, @Param("mpw") String userPw);

	String selectMemberIdCheck(String inputId);

	ArrayList<HashMap<String, String>> selectReserveList(String loginId);

	int deleteReserve(String recode);

	String selectReviewCode(String recode);


}









