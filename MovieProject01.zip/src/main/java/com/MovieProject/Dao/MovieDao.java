package com.MovieProject.Dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.MovieProject.Dto.Movie;
import com.MovieProject.Dto.Reserve;
import com.MovieProject.Dto.Schedule;
import com.MovieProject.Dto.Theater;

public interface MovieDao {
	
	// 영화 인기 순위 조회
	ArrayList<Movie> selectRankMovList();
	// 영화 상세정보 조회
	Movie selectDetailMovie(String mvcode);
	// 영화 목록 조회 ( 모든 예매 가능한 영화, 특정한 극장에서의 예매 가능한 영화 )
	ArrayList<Movie> selectMovieList(String selThCode);
	// 극장 목록 조회
	ArrayList<Theater> selectTheaterList(String selMvcode);
	// 날짜 목록 조회
	ArrayList<Schedule> selectScheduleDateList(@Param("mvcode") String mvcode, @Param("thcode") String thcode);
	// 상영관 시간 조회
	ArrayList<Schedule> selectScheduleTimeList(Schedule sc);
	
	String selectMaxRecode();
	
	int insertReserveInfo(Reserve reinfo);
	
	ArrayList<HashMap<String, String>> selectRecentReserveInfo(String loginId);
	
	HashMap<String, String> selectReserveInfo(String recode);
	
	String selectMaxRvCode();
	
	int insertReview(@Param("rvcode") String rvcode,@Param("recode") String recode, @Param("rvcomment") String rvcomment, @Param("mid") String mid);
	
	ArrayList<HashMap<String, String>> selectMovieReviewList(String mvcode);
	
	
}













