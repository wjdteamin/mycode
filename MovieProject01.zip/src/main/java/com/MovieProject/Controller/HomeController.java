package com.MovieProject.Controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.MovieProject.Dto.Movie;
import com.MovieProject.Dto.Reserve;
import com.MovieProject.Dto.Schedule;
import com.MovieProject.Dto.Theater;
import com.MovieProject.Service.MovieService;
import com.google.gson.Gson;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	@Autowired
	private MovieService mvsvc;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(HttpSession session) {
		System.out.println("메인 페이지 이동요청");
		ModelAndView mav = new ModelAndView();
		//1. 영화 랭킹 목록 조회
		ArrayList<Movie> rankMovList = mvsvc.getRankMovieList();
		mav.addObject("rankMovList", rankMovList);
		String loginId = (String)session.getAttribute("loginId");
		
		if(loginId != null) {
			ArrayList< HashMap< String, String> > recentReserve
				= mvsvc.getRecentReserveInfo(loginId);
			System.out.println(recentReserve);
			mav.addObject("reInfo",recentReserve);
		}
		
		
		//2. 이동 할 페이지 설정
		mav.setViewName("home");
		return mav;
	}
	
	@RequestMapping(value = "/detailMovie")
	public ModelAndView detailMovie(String mvcode) {
		System.out.println("영화 상세 정보 페이지 이동요청");
		ModelAndView mav = new ModelAndView();
		//1. SERVICE - 영화정보 조회 메소드 호출
		Movie movie = mvsvc.getDetailMovie(mvcode);
		System.out.println(movie);
		mav.addObject("movie",movie);
		
		//2. SERVICE - 관람평 목록 조회
		ArrayList< HashMap<String, String> > reviewList
								= mvsvc.getMovieReviewList(mvcode);
		
		mav.addObject("reviewList", reviewList);
		mav.setViewName("movie/DetailMovie");
		return mav;
	}
	
	@RequestMapping(value = "/movieList")
	public ModelAndView movieList() {
		System.out.println("영화 목록 페이지 이동요청 - /movieList");
		ModelAndView mav = new ModelAndView();
		ArrayList<Movie> movList = mvsvc.getMovieList("ALL");
		System.out.println(movList);
		mav.addObject("movList", movList);
		mav.setViewName("movie/MovieList");
		return mav;
	}
	
	@RequestMapping(value = "/reserveMovie")
	public ModelAndView reserveMovie() {
		System.out.println("영화 예매 페이지 이동요청 - /reserveMovie");
		ModelAndView mav = new ModelAndView();
		//예매 가능한 영화 목록
		ArrayList<Movie> movList = mvsvc.getMovieList("ALL");
		mav.addObject("movList", movList);
		//예매 가능한 극장 목록
		ArrayList<Theater> thList = mvsvc.getTheaterList("ALL");
		mav.addObject("thList", thList);		
		
		mav.setViewName("movie/ReservePage");
		return mav;
	}
	
	@RequestMapping(value = "/getMovieList_json")
	public @ResponseBody String getMovieList_json(String selThCode) {
		System.out.println("예매페이지_영화 목록 조회 요청");
		ArrayList<Movie> movList = mvsvc.getMovieList(selThCode);
		return new Gson().toJson(movList);
	}
	

	@RequestMapping(value = "/getTheaterList_json")
	public @ResponseBody String getTheaterList_json(String selMvCode) {
		System.out.println("예매페이지_극장 목록 조회 요청");
		System.out.println("선택한 영화 코드 : " + selMvCode); // "MV00000"
		ArrayList<Theater> thList = mvsvc.getTheaterList(selMvCode);
		return new Gson().toJson(thList);
	}
	
	@RequestMapping(value = "/getSchduleDateList_json")
	public @ResponseBody String getSchduleDateList_json(String mvcode, String thcode) {
		System.out.println("예매페이지_날짜 목록 조회 요청");
		System.out.println("선택한 영화 코드 : " + mvcode); // "MV00011"
		System.out.println("선택한 극장 코드 : " + thcode); // "TH00022"
		ArrayList<Schedule> scList = mvsvc.getScheduleDateList(mvcode, thcode);
		return new Gson().toJson(scList);
	}
	
	//getSchduleTimeList_json
	@RequestMapping(value = "/getSchduleTimeList_json")
	public @ResponseBody String getSchduleTimeList_json(Schedule sc) {
		System.out.println("예매페이지_날짜 목록 조회 요청");
		System.out.println("선택한 영화 코드 : " + sc.getMvcode()); // "MV00011"
		System.out.println("선택한 극장 코드 : " + sc.getThcode()); // "TH00022"
		System.out.println("선택한 날짜 : " + sc.getScdate()); // "2023-09-18"
		ArrayList<Schedule> scList = mvsvc.getScheduleTimeList(sc);
		return new Gson().toJson(scList);
	}	
	
	@RequestMapping(value = "/registReserveInfo")
	public @ResponseBody String registReserveInfo(Reserve reinfo, HttpSession session) {
		System.out.println("예매 처리 요청 - /registReserveInfo");
		System.out.println(reinfo);
		String loginId = (String)session.getAttribute("loginId");
		if(loginId == null) {
			return "login";
		} else {
			reinfo.setMid(loginId);
			String registResult = mvsvc.registReserveInfo(reinfo);
			return registResult; // null || 예매코드
		}
	}
	
	
	@RequestMapping(value = "/reviewWriteForm")
	public ModelAndView reviewWriteForm(String recode) {
		System.out.println("관람평 작성 페이지 이동요청- /reviewWriteForm");
		ModelAndView mav = new ModelAndView();
		// 관람한 영화 정보 조회 
		HashMap<String, String> reserveInfo = mvsvc.getReserveInfo(recode);
		//
		
		System.out.println(reserveInfo);
		mav.addObject("reInfo", reserveInfo);//
		mav.setViewName("movie/ReviewWriteForm");
		return mav;
	}

	@RequestMapping(value = "/registReview")
	public ModelAndView registReview(String recode, String rvcomment, HttpSession session, RedirectAttributes ra) {
		System.out.println("관람평 등록 요청 - /registReview");
		System.out.println("예매코드 : " + recode);
		System.out.println("관람평 : " + rvcomment);
		String mid = (String)session.getAttribute("loginId");
		System.out.println("작성자 : " + mid);
		int registResult = mvsvc.registReview(recode, rvcomment, mid);
		ModelAndView mav = new ModelAndView();
		ra.addFlashAttribute("msg", "관람평이 등록 되었습니다.");
		mav.setViewName("redirect:/reserveList");
		return mav;
		
	}
	
	
}

















