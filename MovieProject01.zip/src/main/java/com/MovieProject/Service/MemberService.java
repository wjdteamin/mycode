package com.MovieProject.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.MovieProject.Dao.MemberDao;
import com.MovieProject.Dto.Member;

@Service
public class MemberService {
	
	@Autowired
	private MemberDao memdao;

	public Member getLoginMemberInfo_kakao(String id) {
		System.out.println("SERVICE - getLoginMemberInfo_kakao() 호출");
		return memdao.selectMemberInfo(id);
	}

	public int registMember_kakao(Member member) {
		System.out.println("SERVICE - registMember_kakao() 호출");
		return memdao.insertMember_kakao(member);
	}

	public int registMember(Member member, HttpSession session) throws IllegalStateException, IOException {
		System.out.println("SERVICE - registMember()");
		// 업로드된 파일 저장 - 저장경로 설정, 중복파일명 처리
		MultipartFile mfile = member.getMfile(); // 첨부파일
		String mprofile = ""; // 파일명 저장할 변수
		String savePath = session.getServletContext().getRealPath("/resources/users/memberProfile"); // 파일을 저장할 경로
		if( !mfile.isEmpty() ){ // 첨부파일 확인
			// 첨부파일이 있는 경우
			System.out.println("첨부파일 있음");
			UUID uuid  = UUID.randomUUID();
			String code = uuid.toString();
			mprofile = code + "_" + mfile.getOriginalFilename();
			//저장할 경로 /resources/users/memberProfile 폴더에 파일저장
			System.out.println("savePath : " + savePath );
			File newFile = new File( savePath  , mprofile );
			mfile.transferTo( newFile );
		} 
		System.out.println("파일이름 : " + mprofile);
		member.setMprofile(mprofile);
		System.out.println(member);
		//dao - insert
		int joinResult = memdao.insertMember(member);
		
		return joinResult;
	}

	public Member getLoginMemberInfo(String userId, String userPw) {
		System.out.println("SERVICE - getLoginMemberInfo()");
		return memdao.selectLoginMember(userId,userPw);
	}

	public String memberIdCheck(String inputId) {
		System.out.println("SERVICE memberIdCheck() 호출");
//		String result = memdao.selectMemberIdCheck(inputId);
//		if(result == null) {
//			return "Y";
//		} else {
//			return "N";
//		}
        return memdao.selectMemberIdCheck(inputId);
	}

	public ArrayList<HashMap<String, String>> getReserveList(String loginId) {
		
		ArrayList< HashMap<String, String> > reList 
		                = memdao.selectReserveList(loginId);
		for(HashMap<String, String> re : reList) {
			String recode = re.get("RECODE"); // 
			String rvcode = memdao.selectReviewCode(recode);
			re.put("RVCODE", rvcode);
		}
		
		return reList;
	}

	public int cancelReserve(String recode) {
		
		return memdao.deleteReserve(recode);
	}

}













