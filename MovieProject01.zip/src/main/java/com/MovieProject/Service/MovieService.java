package com.MovieProject.Service;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MovieProject.Dao.MovieDao;
import com.MovieProject.Dto.Movie;
import com.MovieProject.Dto.Reserve;
import com.MovieProject.Dto.Schedule;
import com.MovieProject.Dto.Theater;

@Service 
public class MovieService {
	
	@Autowired
	private MovieDao mvdao;

	public ArrayList<Movie> getRankMovieList() {
		System.out.println("SERVICE - 영화 목록 조회_랭킹");
		ArrayList<Movie> movList = mvdao.selectRankMovList();
		
		int totalCount = 0;
		for(Movie mov : movList) {
			totalCount +=  Integer.parseInt(mov.getRecount()); // totalCount = totalCount + mov.getRecount();
			String movGrade = mov.getMvinfo().split(",")[0];
			// [15세이상관람가] [101분] [한국]
			//movGrade = movGrade.substring(0, 2);
			if(movGrade.equals("전체관람가")) {
				movGrade = "All";
			} else if( movGrade.equals("청소년관람불가") ) {
				movGrade = "18";
			} else if( movGrade.equals("15세이상관람가") ) {
				movGrade = "15";
			} else {
				movGrade = "12";
			}
			mov.setMvstate(movGrade);
		}		
		//totalCount = 총합
		for(Movie mv : movList) {
			int recount = Integer.parseInt(mv.getRecount());
			double reRate = ( (double)recount / totalCount) * 100; // 26.022324
			String recount_str =( Math.round(reRate * 100) /100.0 )+ "";
			mv.setRecount(  recount_str  );

		}
		
		return movList;
	}

	public Movie getDetailMovie(String mvcode) {
		System.out.println("SERVICE - 영화 정보 조회");
		return mvdao.selectDetailMovie(mvcode);
	}
	

	public ArrayList<Movie> getMovieList(String selThCode) {
		System.out.println("SERVICE - getMovieList()");
		ArrayList<Movie> movList = mvdao.selectMovieList(selThCode);
		
		for(Movie mov : movList) {
			String movGrade = mov.getMvinfo().split(",")[0];
			// [15세이상관람가] [101분] [한국]
			//movGrade = movGrade.substring(0, 2);
			if(movGrade.equals("전체관람가")) {
				movGrade = "All";
			} else if( movGrade.equals("청소년관람불가") ) {
				movGrade = "18";
			} else if( movGrade.equals("15세이상관람가") ) {
				movGrade = "15";
			} else {
				movGrade = "12";
			}
			
			mov.setMvstate(movGrade);
		}
		
		
		return movList;
	}

	public ArrayList<Theater> getTheaterList(String selMvcode) {
		System.out.println("SERVICE - getTheaterList()");
		return mvdao.selectTheaterList(selMvcode);
	}

	public ArrayList<Schedule> getScheduleDateList(String mvcode, String thcode) {
		System.out.println("SERVICE - getScheduleDateList()");
		return mvdao.selectScheduleDateList(mvcode, thcode);
	}

	public ArrayList<Schedule> getScheduleTimeList(Schedule sc) {
		// TODO Auto-generated method stub
		return mvdao.selectScheduleTimeList(sc);
	}

	@Autowired
	private AdminService adminsvc;
	
	public String registReserveInfo(Reserve reinfo) {
		//1. 예매코드 생성('RE00001');
		String maxRecode = mvdao.selectMaxRecode(); 
		// SELECT NVL(MAX(RECODE),'RE00000') FROM RESERVES
		String recode = adminsvc.genCode(maxRecode);
		reinfo.setRecode(recode);
		//2. DAO - INSERT
		int insertResult = 0;
		try {
			insertResult = mvdao.insertReserveInfo(reinfo);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		if(insertResult > 0) {
			return recode;
		} else {
			return null;
		}
		
	}

	public ArrayList<HashMap<String, String>> getRecentReserveInfo(String loginId) {
		// TODO Auto-generated method stub
		return mvdao.selectRecentReserveInfo(loginId);
	}

	public HashMap<String, String> getReserveInfo(String recode) {
		// TODO Auto-generated method stub
		return mvdao.selectReserveInfo(recode);
	}

	public int registReview(String recode, String rvcomment, String mid) {
		System.out.println("service - registReview()");
		String maxRvCode = mvdao.selectMaxRvCode();
		String rvcode = adminsvc.genCode(maxRvCode);
		return mvdao.insertReview(rvcode, recode, rvcomment, mid);
	}

	public ArrayList<HashMap<String, String>> getMovieReviewList(String mvcode) {
		
		return mvdao.selectMovieReviewList(mvcode);
	}



}













